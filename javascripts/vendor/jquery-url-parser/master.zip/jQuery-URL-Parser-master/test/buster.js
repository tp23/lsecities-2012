var config = module.exports;

config["Tests"] = {
    rootPath: "../",
    environment: "browser",
    sources: [
        "purl.js"
    ],

    tests: [
        "test/purl-tests.js"
    ]
}
